<?php declare(strict_types = 0);
/**
 * World Clocks widget module.
 */

namespace Modules\Worldclocks;

use Zabbix\Core\CWidget;

class Widget extends CWidget {

	public const TYPE_DIGITAL = 0;
	public const TYPE_ANALOG = 1;

	// Zabbix has no generic "repeatable field group" type outside the heavyweight
	// CWidgetFieldColumnsList (built for tophosts' table columns, not a fit here) -- a fixed
	// number of optional slots, each a plain CWidgetFieldSelect (time zone) + two
	// CWidgetFieldTextBox fields, is the right-sized real API for a small, fixed-layout
	// "row of clocks" widget.
	public const CLOCK_SLOT_COUNT = 8;

	// Pre-filled defaults for a freshly-added widget instance -- editable afterwards via the
	// widget's own configuration form (includes/WidgetForm.php), not hardcoded at runtime.
	// "label" left blank on every entry so the front end computes the live, DST-correct zone
	// abbreviation via Intl.DateTimeFormat rather than a fixed string that can go stale twice a
	// year (e.g. London showing "BST" through a UK winter).
	public const DEFAULT_CLOCKS = [
		['tz' => 'America/Los_Angeles', 'city' => 'Los Angeles', 'label' => ''],
		['tz' => 'America/New_York',    'city' => 'New York',    'label' => ''],
		['tz' => 'Europe/London',       'city' => 'London',      'label' => ''],
		['tz' => 'Europe/Copenhagen',   'city' => 'Copenhagen',  'label' => ''],
		['tz' => 'Australia/Sydney',    'city' => 'Sydney',      'label' => ''],
		['tz' => 'Australia/Melbourne', 'city' => 'Melbourne',   'label' => ''],
		['tz' => 'Pacific/Auckland',    'city' => 'Auckland',    'label' => '']
	];

	public function getDefaultName(): string {
		return _('World Clocks');
	}
}
