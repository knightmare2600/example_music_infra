<?php declare(strict_types = 0);
/**
 * World Clocks widget module.
 */

namespace Widgets\Worldclocks;

use Zabbix\Core\CWidget;

class Widget extends CWidget {

	public function getDefaultName(): string {
		return _('World Clocks');
	}
}
