<?php declare(strict_types = 0);
/**
 * World Clocks widget module.
 */

namespace Modules\Worldclocks;

use Zabbix\Core\CWidget;

class Widget extends CWidget {

	public function getDefaultName(): string {
		return _('World Clocks');
	}
}
