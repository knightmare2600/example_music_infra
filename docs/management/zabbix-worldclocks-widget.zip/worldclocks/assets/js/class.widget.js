/**
 * World Clocks widget front-end class.
 *
 * Lifecycle methods (onInitialize, processUpdateResponse, onDeactivate) match the pattern used
 * by Zabbix's own native Clock widget (widgets/clock/assets/js/class.widget.js): the server
 * renders the five clock cells once (see views/widget.view.php), then this class finds them via
 * this._target and ticks their displayed time every second entirely client-side using
 * Intl.DateTimeFormat against each cell's data-tz attribute -- no further server round trips.
 */
class CWidgetWorldClocks extends CWidget {

	static UPDATE_INTERVAL_MS = 1000;

	onInitialize() {
		this._interval_id = null;
		this._formatters = new Map();
	}

	onDeactivate() {
		this._stopClock();
	}

	processUpdateResponse(response) {
		super.processUpdateResponse(response);

		this._stopClock();
		this._startClock();
	}

	_startClock() {
		this._tick();
		this._interval_id = setInterval(() => this._tick(), CWidgetWorldClocks.UPDATE_INTERVAL_MS);
	}

	_stopClock() {
		if (this._interval_id !== null) {
			clearInterval(this._interval_id);
			this._interval_id = null;
		}
	}

	/**
	 * One Intl.DateTimeFormat instance per time zone, reused across ticks rather than
	 * reconstructed every second.
	 *
	 * @param {string} time_zone  IANA time zone identifier, e.g. "Europe/London".
	 *
	 * @returns {Intl.DateTimeFormat}
	 */
	_getFormatter(time_zone) {
		if (!this._formatters.has(time_zone)) {
			this._formatters.set(time_zone, new Intl.DateTimeFormat('en-GB', {
				timeZone: time_zone,
				hourCycle: 'h23',
				hour: '2-digit',
				minute: '2-digit',
				second: '2-digit'
			}));
		}

		return this._formatters.get(time_zone);
	}

	/**
	 * Builds a deterministic "HH:MM:SS" string for the given time zone, independent of the
	 * browser's own locale punctuation/ordering -- formatToParts() is used (rather than trusting
	 * the formatter's own formatted string) specifically so the separator and field order stay
	 * fixed regardless of which locale the browser reports.
	 *
	 * @param {string} time_zone
	 * @param {Date}   now
	 *
	 * @returns {string}
	 */
	_formatTime(time_zone, now) {
		const parts = this._getFormatter(time_zone).formatToParts(now);
		const get = type => parts.find(part => part.type === type)?.value ?? '--';

		return `${get('hour')}:${get('minute')}:${get('second')}`;
	}

	_tick() {
		const now = new Date();

		for (const cell of this._target.querySelectorAll('.worldclocks-cell')) {
			const time_zone = cell.dataset.tz;
			const time_element = cell.querySelector('.worldclocks-time');

			if (time_zone === undefined || time_element === null) {
				continue;
			}

			try {
				time_element.textContent = this._formatTime(time_zone, now);
			}
			catch (error) {
				// Invalid/unsupported IANA time zone identifier -- leave the placeholder in place.
				time_element.textContent = '--:--:--';
			}
		}
	}
}
