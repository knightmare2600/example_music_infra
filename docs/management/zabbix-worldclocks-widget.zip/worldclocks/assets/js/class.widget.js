/**
 * World Clocks widget front-end class.
 *
 * Lifecycle methods (onInitialize, processUpdateResponse, onDeactivate) match the pattern used
 * by Zabbix's own native Clock widget. The server renders the clock cells once (see
 * views/widget.view.php), then this class finds them via this._target and ticks every second
 * entirely client-side using Intl.DateTimeFormat against each cell's data-tz attribute -- no
 * further server round trips.
 *
 * Digital mode updates three <span> digit groups per cell (hour/minute/second) around two static
 * colon characters, so the colon can blink via CSS without the digits themselves flickering.
 * Analog mode rotates the same .clock-hand-h/-m/-s elements Zabbix's own native Clock widget
 * uses (assets/css/widget.css reuses that exact SVG markup via CClock.php), computed per-cell in
 * that cell's own time zone rather than the browser's local time.
 */
class CWidgetWorldClocks extends CWidget {

	static TYPE_DIGITAL = 0;
	static TYPE_ANALOG = 1;

	static UPDATE_INTERVAL_MS = 1000;

	onInitialize() {
		this._interval_id = null;
		this._clock_type = CWidgetWorldClocks.TYPE_DIGITAL;
		this._time_formatters = new Map();
		this._label_formatters = new Map();
	}

	onDeactivate() {
		this._stopClock();
	}

	processUpdateResponse(response) {
		super.processUpdateResponse(response);

		this._clock_type = response.clock_type ?? CWidgetWorldClocks.TYPE_DIGITAL;

		this._stopClock();
		this._startClock();
	}

	_startClock() {
		this._tick();
		this._interval_id = setInterval(() => this._tick(), CWidgetWorldClocks.UPDATE_INTERVAL_MS);
	}

	_stopClock() {
		if (this._interval_id !== null) {
			clearInterval(this._interval_id);
			this._interval_id = null;
		}
	}

	/**
	 * One Intl.DateTimeFormat instance per time zone for the digits, reused across ticks.
	 *
	 * @param {string} time_zone  IANA time zone identifier, e.g. "Europe/London".
	 *
	 * @returns {Intl.DateTimeFormat}
	 */
	_getTimeFormatter(time_zone) {
		if (!this._time_formatters.has(time_zone)) {
			this._time_formatters.set(time_zone, new Intl.DateTimeFormat('en-GB', {
				timeZone: time_zone,
				hourCycle: 'h23',
				hour: '2-digit',
				minute: '2-digit',
				second: '2-digit'
			}));
		}

		return this._time_formatters.get(time_zone);
	}

	/**
	 * One Intl.DateTimeFormat instance per time zone for the auto-computed zone abbreviation
	 * (used only for cells whose Label field was left blank -- see views/widget.view.php's
	 * data-auto attribute). "short" asks ICU for e.g. "GMT"/"BST"/"PDT" rather than a fixed
	 * offset; exact output depends on the browser's own ICU data, not something this code
	 * controls.
	 *
	 * @param {string} time_zone
	 *
	 * @returns {Intl.DateTimeFormat}
	 */
	_getLabelFormatter(time_zone) {
		if (!this._label_formatters.has(time_zone)) {
			this._label_formatters.set(time_zone, new Intl.DateTimeFormat('en-GB', {
				timeZone: time_zone,
				timeZoneName: 'short',
				hour: '2-digit'
			}));
		}

		return this._label_formatters.get(time_zone);
	}

	/**
	 * @param {string} time_zone
	 * @param {Date}   now
	 *
	 * @returns {{hour: number, minute: number, second: number}}
	 */
	_getTimeParts(time_zone, now) {
		const parts = this._getTimeFormatter(time_zone).formatToParts(now);
		const get = type => parseInt(parts.find(part => part.type === type)?.value ?? '0', 10);

		return {
			hour: get('hour'),
			minute: get('minute'),
			second: get('second')
		};
	}

	_tick() {
		const now = new Date();

		for (const cell of this._target.querySelectorAll('.worldclocks-cell')) {
			const time_zone = cell.dataset.tz;

			if (time_zone === undefined) {
				continue;
			}

			try {
				const time = this._getTimeParts(time_zone, now);

				if (this._clock_type === CWidgetWorldClocks.TYPE_ANALOG) {
					this._tickAnalog(cell, time);
				}
				else {
					this._tickDigital(cell, time);
				}
			}
			catch (error) {
				// Invalid/unsupported IANA time zone identifier -- leave whatever was last shown.
			}

			this._tickLabel(cell, time_zone, now);
		}
	}

	_tickDigital(cell, time) {
		const pad = value => String(value).padStart(2, '0');

		const h = cell.querySelector('.worldclocks-h');
		const m = cell.querySelector('.worldclocks-m');
		const s = cell.querySelector('.worldclocks-s');

		if (h !== null) {
			h.textContent = pad(time.hour);
		}

		if (m !== null) {
			m.textContent = pad(time.minute);
		}

		if (s !== null) {
			s.textContent = pad(time.second);
		}
	}

	_tickAnalog(cell, time) {
		const hand_h = cell.querySelector('.clock-hand-h');
		const hand_m = cell.querySelector('.clock-hand-m');
		const hand_s = cell.querySelector('.clock-hand-s');

		const h = time.hour % 12;
		const m = time.minute;
		const s = time.second;

		if (hand_h !== null) {
			this._rotateHand(hand_h, 30 * (h + m / 60 + s / 3600));
		}

		if (hand_m !== null) {
			this._rotateHand(hand_m, 6 * (m + s / 60));
		}

		if (hand_s !== null) {
			this._rotateHand(hand_s, 6 * s);
		}
	}

	_rotateHand(hand_element, degrees) {
		hand_element.setAttribute('transform', `rotate(${degrees} 50 50)`);
	}

	_tickLabel(cell, time_zone, now) {
		const label_element = cell.querySelector('.worldclocks-label[data-auto]');

		if (label_element === null) {
			return;
		}

		try {
			const parts = this._getLabelFormatter(time_zone).formatToParts(now);
			const zone_name = parts.find(part => part.type === 'timeZoneName')?.value;

			if (zone_name !== undefined) {
				label_element.textContent = zone_name;
			}
		}
		catch (error) {
			// Leave whatever label text (placeholder or previous tick's value) is already there.
		}
	}
}
