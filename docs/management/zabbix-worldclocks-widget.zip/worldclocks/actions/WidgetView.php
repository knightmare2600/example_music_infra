<?php declare(strict_types = 0);
/**
 * World Clocks widget view action.
 *
 * Reads the operator's configured clock slots (Widget::CLOCK_SLOT_COUNT of them, each a
 * tz_N/city_N/label_N field trio) and passes only the populated ones down as a plain list --
 * the front end never needs to know about the fixed slot count.
 */

namespace Modules\Worldclocks\Actions;

use CControllerDashboardWidgetView,
	CControllerResponseData;

use Modules\Worldclocks\Widget;

class WidgetView extends CControllerDashboardWidgetView {

	protected function doAction(): void {
		$clocks = [];

		for ($i = 1; $i <= Widget::CLOCK_SLOT_COUNT; $i++) {
			$tz = $this->fields_values['tz_'.$i];

			if ($tz === '') {
				continue;
			}

			$city = $this->fields_values['city_'.$i];

			$clocks[] = [
				'tz' => $tz,
				'city' => $city !== '' ? $city : $this->deriveCityFromTimezone($tz),
				'label' => $this->fields_values['label_'.$i]
			];
		}

		$this->setResponse(new CControllerResponseData([
			'name' => $this->getInput('name', $this->widget->getDefaultName()),
			'clocks' => $clocks,
			'clock_type' => (int) $this->fields_values['clock_type'],
			'blink_colon' => $this->fields_values['blink_colon'] == 1,
			'fg_color' => $this->fields_values['fg_color'],
			'bg_color' => $this->fields_values['bg_color'],
			'user' => [
				'debug_mode' => $this->getDebugMode()
			]
		]));
	}

	/**
	 * Fallback city label when the operator leaves the City field blank -- the last path
	 * segment of the IANA identifier with underscores turned into spaces, e.g.
	 * "America/Los_Angeles" -> "Los Angeles".
	 */
	private function deriveCityFromTimezone(string $tz): string {
		$pos = strrpos($tz, '/');
		$name = $pos === false ? $tz : substr($tz, $pos + 1);

		return str_replace('_', ' ', $name);
	}
}
