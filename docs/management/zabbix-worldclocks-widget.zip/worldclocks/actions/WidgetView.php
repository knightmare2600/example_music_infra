<?php declare(strict_types = 0);
/**
 * World Clocks widget view action.
 *
 * The clock list (IANA time zone, fixed label, city) is the single source of truth for the
 * widget's content -- defined once here in PHP and rendered into data-tz attributes; the
 * front-end JavaScript reads those attributes rather than duplicating this list.
 */

namespace Modules\Worldclocks\Actions;

use CControllerDashboardWidgetView,
	CControllerResponseData;

class WidgetView extends CControllerDashboardWidgetView {

	protected function doAction(): void {
		$this->setResponse(new CControllerResponseData([
			'name' => $this->getInput('name', $this->widget->getDefaultName()),
			'clocks' => [
				['tz' => 'America/Los_Angeles', 'label' => 'PDT',     'city' => 'Los Angeles'],
				['tz' => 'America/New_York',    'label' => 'EDT',     'city' => 'New York'],
				['tz' => 'Europe/London',       'label' => 'BST/GMT', 'city' => 'London'],
				['tz' => 'Europe/Copenhagen',   'label' => 'CET',     'city' => 'Copenhagen'],
				['tz' => 'Australia/Sydney',    'label' => 'AET',     'city' => 'Sydney'],
				['tz' => 'Australia/Melbourne', 'label' => 'AET',     'city' => 'Melbourne'],
				['tz' => 'Pacific/Auckland',    'label' => 'NZT',     'city' => 'Auckland']
			],
			'user' => [
				'debug_mode' => $this->getDebugMode()
			]
		]));
	}
}
