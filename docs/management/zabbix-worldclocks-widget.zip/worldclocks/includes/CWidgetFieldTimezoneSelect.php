<?php declare(strict_types = 0);
/**
 * A plain CWidgetFieldSelect whose only purpose is calling setSaveType(ZBX_WIDGET_FIELD_TYPE_STR)
 * from within the class hierarchy.
 *
 * Confirmed live (2026-09-03): CWidgetField::setSaveType() is declared `protected`, so it cannot
 * be called on a CWidgetFieldSelect instance from outside CWidgetField's own class hierarchy
 * (e.g. not from WidgetForm.php, which doesn't extend CWidgetField) -- PHP fatals with
 * "Call to protected method ... from scope ...". Every native Zabbix field that needs a
 * non-default save type (CWidgetFieldTimeZone, CWidgetFieldTimePeriod, CWidgetFieldMultiSelect,
 * svggraph's CWidgetFieldDataSet, etc.) follows this exact same pattern -- a small dedicated
 * subclass, never an external ->setSaveType() call. This is that subclass for this widget's
 * string-keyed (IANA identifier) time zone select.
 */

namespace Modules\Worldclocks\Includes;

use Zabbix\Widgets\Fields\CWidgetFieldSelect;

class CWidgetFieldTimezoneSelect extends CWidgetFieldSelect {

	public function __construct(string $name, string $label, array $values) {
		parent::__construct($name, $label, $values);

		$this->setSaveType(ZBX_WIDGET_FIELD_TYPE_STR);
	}
}
