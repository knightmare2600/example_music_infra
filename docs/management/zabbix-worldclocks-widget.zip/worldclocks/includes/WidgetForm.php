<?php declare(strict_types = 0);
/**
 * World Clocks widget form.
 *
 * The five clocks (time zone, label, city) are fixed in WidgetView.php rather than
 * user-configurable, so this form intentionally adds no fields of its own. Zabbix's core
 * CWidget::getForm() still adds the standard "Refresh interval" field automatically.
 */

namespace Modules\Worldclocks\Includes;

use Zabbix\Widgets\CWidgetForm;

class WidgetForm extends CWidgetForm {

	public function addFields(): self {
		return $this;
	}
}
