<?php declare(strict_types = 0);
/**
 * World Clocks widget form.
 */

namespace Modules\Worldclocks\Includes;

use Zabbix\Widgets\CWidgetForm;

use Zabbix\Widgets\Fields\{
	CWidgetFieldCheckBox,
	CWidgetFieldColor,
	CWidgetFieldRadioButtonList,
	CWidgetFieldSelect,
	CWidgetFieldTextBox
};

use CTimezoneHelper;

use Modules\Worldclocks\Widget;

class WidgetForm extends CWidgetForm {

	public function validate(bool $strict = false): array {
		$errors = parent::validate($strict);

		if ($errors) {
			return $errors;
		}

		$has_clock = false;

		for ($i = 1; $i <= Widget::CLOCK_SLOT_COUNT; $i++) {
			if ($this->getFieldValue('tz_'.$i) !== '') {
				$has_clock = true;
				break;
			}
		}

		if (!$has_clock) {
			$errors[] = _('At least one clock (time zone) must be configured.');
		}

		return $errors;
	}

	public function addFields(): self {
		$this
			->addField(
				(new CWidgetFieldRadioButtonList('clock_type', _('Clock type'), [
					Widget::TYPE_DIGITAL => _('Digital'),
					Widget::TYPE_ANALOG => _('Analog')
				]))->setDefault(Widget::TYPE_DIGITAL)
			)
			->addField(
				(new CWidgetFieldCheckBox('blink_colon', _('Blink colon (digital only)')))->setDefault(0)
			)
			->addField(
				(new CWidgetFieldColor('fg_color', _('Foreground colour')))->allowInherited()
			)
			->addField(
				(new CWidgetFieldColor('bg_color', _('Background colour')))->allowInherited()
			);

		// Deliberately plain CWidgetFieldSelect, not Zabbix's own CWidgetFieldTimeZone --
		// confirmed live (2026-09-03) that CWidgetFieldTimeZone's $values constructor
		// parameter is non-functional: its constructor is `$values === null ? [built-in
		// defaults] : null`, so passing a custom array actually results in `null` being passed
		// to the parent CWidgetFieldSelect, which requires a non-nullable array -- a hard
		// TypeError on every dashboard load. Real IANA identifiers only (PHP's own
		// DateTimeZone::listIdentifiers(), via CTimezoneHelper::getList(), confirmed to return
		// the flat ["Europe/London" => "(UTC+00:00) Europe/London", ...] shape CWidgetFieldSelect
		// expects) plus our own "(not used)" sentinel -- CWidgetFieldSelect defaults to
		// ZBX_WIDGET_FIELD_TYPE_INT32 save type, so it must be set to STR explicitly for string
		// zone keys to round-trip correctly.
		$timezone_values = ['' => _('(not used)')] + CTimezoneHelper::getList();

		for ($i = 1; $i <= Widget::CLOCK_SLOT_COUNT; $i++) {
			$default = Widget::DEFAULT_CLOCKS[$i - 1] ?? ['tz' => '', 'city' => '', 'label' => ''];

			$this
				->addField(
					(new CWidgetFieldSelect('tz_'.$i, _s('Clock %1$d — Time zone', $i), $timezone_values))
						->setDefault($default['tz'])
						->setSaveType(ZBX_WIDGET_FIELD_TYPE_STR)
				)
				->addField(
					(new CWidgetFieldTextBox('city_'.$i, _s('Clock %1$d — City', $i)))
						->setDefault($default['city'])
				)
				->addField(
					(new CWidgetFieldTextBox('label_'.$i, _s('Clock %1$d — Label (blank = auto)', $i)))
						->setDefault($default['label'])
				);
		}

		return $this;
	}
}
