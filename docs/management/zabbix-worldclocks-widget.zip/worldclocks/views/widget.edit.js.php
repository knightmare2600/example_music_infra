<?php declare(strict_types = 0);
/**
 * World Clocks widget form JS.
 *
 * Zabbix's own CWidgetFieldColorView deliberately renders each colour field with
 * appendColorPickerJs(false) (confirmed live, 2026-09-03, by reading CColor.php/
 * CWidgetFieldColorView.php directly) -- the interactive colour-picker popup is never activated
 * automatically. Every native widget with a colour field (e.g. the built-in Clock widget) does
 * this exact same manual activation itself in its own widget.edit.js.php; this is that file for
 * this widget's fg_color/bg_color fields, adapted directly from Clock's own real code.
 */
?>

window.worldclocks_form = new class {

	init() {
		const form = document.getElementById('widget-dialogue-form');

		for (const colorpicker of form.querySelectorAll('.<?= ZBX_STYLE_COLOR_PICKER ?> input')) {
			jQuery(colorpicker).colorpicker({
				appendTo: '.overlay-dialogue-body',
				use_default: true
			});
		}
	}
};
