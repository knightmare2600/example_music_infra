<?php declare(strict_types = 0);
/**
 * World Clocks widget view.
 *
 * Renders one .worldclocks-cell per configured clock. The time text is filled in and ticked
 * every second entirely client-side (assets/js/class.widget.js), so the "--:--:--" placeholder
 * here is only ever visible for the instant before JavaScript first runs.
 *
 * @var CView $this
 * @var array $data
 */

$row = (new CDiv())->addClass('worldclocks-row');

foreach ($data['clocks'] as $clock) {
	$cell = (new CDiv())
		->addClass('worldclocks-cell')
		->setAttribute('data-tz', $clock['tz']);

	$cell->addItem((new CDiv($clock['label']))->addClass('worldclocks-label'));
	$cell->addItem((new CDiv('--:--:--'))->addClass('worldclocks-time'));
	$cell->addItem((new CDiv($clock['city']))->addClass('worldclocks-city'));

	$row->addItem($cell);
}

(new CWidgetView($data))
	->addItem($row)
	->show();
