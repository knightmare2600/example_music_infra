<?php declare(strict_types = 0);
/**
 * World Clocks widget view.
 *
 * Renders one .worldclocks-cell per configured clock, digital or analog per $data['clock_type'].
 * All ticking (time, and the auto-computed label when the operator left it blank) happens
 * entirely client-side every second (assets/js/class.widget.js) -- this view only ever needs to
 * render the initial static structure once.
 *
 * @var CView $this
 * @var array $data
 */

use Modules\Worldclocks\Widget;

$row = (new CDiv())->addClass('worldclocks-row');

if ($data['fg_color'] !== '') {
	$row->addStyle('--worldclocks-fg: #'.$data['fg_color'].';');
}

if ($data['bg_color'] !== '') {
	$row->addStyle('--worldclocks-bg: #'.$data['bg_color'].';');
}

$is_analog = ($data['clock_type'] == Widget::TYPE_ANALOG);

if ($is_analog) {
	$row->addClass('worldclocks-analog');
}

foreach ($data['clocks'] as $clock) {
	$cell = (new CDiv())
		->addClass('worldclocks-cell')
		->setAttribute('data-tz', $clock['tz']);

	if ($is_analog) {
		$cell->addItem((new CClock())->setEnabled(true));
	}
	else {
		$time = (new CDiv([
			(new CSpan('--'))->addClass('worldclocks-h'),
			(new CSpan(':'))->addClass('worldclocks-colon'),
			(new CSpan('--'))->addClass('worldclocks-m'),
			(new CSpan(':'))->addClass('worldclocks-colon'),
			(new CSpan('--'))->addClass('worldclocks-s')
		]))->addClass('worldclocks-time');

		if ($data['blink_colon']) {
			$time->addClass('worldclocks-blink');
		}

		$cell->addItem($time);
	}

	$label = (new CDiv($clock['label']))->addClass('worldclocks-label');

	if ($clock['label'] === '') {
		// No manual label -- assets/js/class.widget.js computes and fills this in every tick
		// via Intl.DateTimeFormat's timeZoneName, so it stays correct across DST transitions
		// (e.g. London genuinely shows GMT or BST depending on the date, not a fixed string).
		$label->setAttribute('data-auto', '1');
	}

	$cell->addItem($label);
	$cell->addItem((new CDiv($clock['city']))->addClass('worldclocks-city'));

	$row->addItem($cell);
}

(new CWidgetView($data))
	->addItem($row)
	->show();
