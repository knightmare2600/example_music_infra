<?php declare(strict_types = 0);
/**
 * World Clocks widget edit form view.
 *
 * No custom fields -- the five clocks are fixed (see actions/WidgetView.php). CWidgetFormView
 * still renders the standard "Refresh interval" field that Zabbix's core adds automatically to
 * every widget's form.
 *
 * @var CView $this
 * @var array $data
 */

(new CWidgetFormView($data))
	->show();
