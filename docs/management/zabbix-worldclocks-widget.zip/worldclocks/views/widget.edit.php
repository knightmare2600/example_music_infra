<?php declare(strict_types = 0);
/**
 * World Clocks widget edit form view.
 *
 * @var CView $this
 * @var array $data
 */

use Modules\Worldclocks\Widget;

$form = (new CWidgetFormView($data))
	->addField(
		new CWidgetFieldRadioButtonListView($data['fields']['clock_type'])
	)
	->addField(
		new CWidgetFieldCheckBoxView($data['fields']['blink_colon'])
	)
	->addField(
		new CWidgetFieldColorView($data['fields']['fg_color'])
	)
	->addField(
		new CWidgetFieldColorView($data['fields']['bg_color'])
	);

$clocks_fieldset = new CWidgetFormFieldsetCollapsibleView(_('Clocks'));

for ($i = 1; $i <= Widget::CLOCK_SLOT_COUNT; $i++) {
	$clocks_fieldset->addFieldsGroup(
		(new CWidgetFieldsGroupView(_s('Clock %1$d', $i)))
			->addField(
				new CWidgetFieldTimeZoneView($data['fields']['tz_'.$i])
			)
			->addField(
				new CWidgetFieldTextBoxView($data['fields']['city_'.$i])
			)
			->addField(
				new CWidgetFieldTextBoxView($data['fields']['label_'.$i])
			)
	);
}

$form
	->addFieldset($clocks_fieldset)
	->show();
